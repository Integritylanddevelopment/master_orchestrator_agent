# README.md

Welcome to the Setup Protocol.

Execute folders in sequence. Do not skip or assume.

## Execution Sequence:

1. Open `01_COO/` and execute `COO.md`. Then stop.
2. Wait for confirmation.
3. Once approved, open `02_CEO_Deploy/` and execute `DeployCEO.md`.
